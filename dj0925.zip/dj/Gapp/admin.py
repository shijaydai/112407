from django.contrib import admin
from Gapp import models

admin.site.register(models.dj)
